plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "jp.example.challenge"
    compileSdk = 35
    defaultConfig {
        applicationId = "jp.example.challenge"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
