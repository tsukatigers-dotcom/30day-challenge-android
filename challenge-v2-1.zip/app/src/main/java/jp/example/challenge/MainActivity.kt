package jp.example.challenge

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pendingBackupJson: String? = null

    companion object {
        private const val REQUEST_NOTIFICATION = 107
        private const val REQUEST_EXPORT = 205
        private const val REQUEST_IMPORT = 206
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(android.graphics.Color.rgb(16, 17, 20))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowContentAccess = false
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return request?.url?.toString()?.startsWith("file:///android_asset/") != true
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun js(code: String) {
        runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(code, null) }
    }

    inner class Bridge {
        @JavascriptInterface fun getReminderTime(): String = ReminderScheduler.getTime(this@MainActivity)

        @JavascriptInterface fun setReminder(value: String) {
            runOnUiThread {
                if (!Regex("(?:[01][0-9]|2[0-3]):[0-5][0-9]").matches(value)) return@runOnUiThread
                ReminderScheduler.enable(this@MainActivity, value)
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATION)
                } else {
                    js("window.onNotificationPermissionChanged(true)")
                }
            }
        }

        @JavascriptInterface fun clearReminder() {
            runOnUiThread {
                ReminderScheduler.disable(this@MainActivity)
                js("window.onNotificationPermissionChanged(true)")
            }
        }

        @JavascriptInterface fun exportBackup(json: String) {
            runOnUiThread {
                pendingBackupJson = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "challenge-records-backup.json")
                }
                startActivityForResult(intent, REQUEST_EXPORT)
            }
        }

        @JavascriptInterface fun importBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivityForResult(intent, REQUEST_IMPORT)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIFICATION) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            js("window.onNotificationPermissionChanged(${if (granted) "true" else "false"})")
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_EXPORT) {
            var exported = false
            if (resultCode == RESULT_OK && data?.data != null) {
                try {
                    contentResolver.openOutputStream(data.data!!)?.use { stream ->
                        stream.write((pendingBackupJson ?: "").toByteArray(Charsets.UTF_8))
                        exported = true
                    }
                } catch (_: Exception) { exported = false }
            }
            pendingBackupJson = null
            js("window.onBackupExported(${if (exported) "true" else "false"})")
        } else if (requestCode == REQUEST_IMPORT && resultCode == RESULT_OK && data?.data != null) {
            try {
                // 2 MB is ample for multi-year local records; reject unexpectedly large files.
                val content = contentResolver.openInputStream(data.data!!)?.use { stream ->
                    val buffer = ByteArray(8192)
                    val output = ByteArrayOutputStream()
                    while (true) {
                        val bytes = stream.read(buffer)
                        if (bytes < 0) break
                        output.write(buffer, 0, bytes)
                        if (output.size() > 2_000_000) error("Too large")
                    }
                    output.toByteArray()
                } ?: return
                val json = JSONObject.quote(String(content, Charsets.UTF_8))
                js("window.receiveNativeBackup($json)")
            } catch (_: Exception) {
                js("window.receiveNativeBackup('invalid backup')")
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
