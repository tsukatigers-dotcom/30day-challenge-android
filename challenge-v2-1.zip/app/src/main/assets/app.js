"use strict";

// LEGACY STORAGE CONTRACT (version 1/1.1): day, checks, records, reminder, continue.
// Keep these keys and the `${day}-${task}` check identifiers to read existing data
// without copying or deleting it when an in-place update is possible.
const plans = [
  ["ウォームアップ・軽い足踏み 5分", "スクワット 10回×2セット", "骨盤底筋をやさしく締める・緩める 10回", "ゆっくり深呼吸・ストレッチ 5分"],
  ["ウォームアップ 5分", "ヒップリフト 12回×2セット", "骨盤底筋トレーニング 10回", "ストレッチ 5分"],
  ["ウォームアップ 5分", "ランジ 左右8回ずつ", "骨盤底筋トレーニング 10回", "深呼吸・ストレッチ 5分"]
];
const DAYS = 30;
const MAX_DAY = 3650;
const $ = (id) => document.getElementById(id);
const get = (key) => localStorage.getItem(key);
const set = (key, value) => localStorage.setItem(key, value);
function safeObject(json) {
  try { const data = JSON.parse(json || "{}"); return data && typeof data === "object" && !Array.isArray(data) ? data : {}; }
  catch { return {}; }
}
const clamp = (value, lower, upper) => Math.max(lower, Math.min(upper, Number.isFinite(Number(value)) ? Math.floor(Number(value)) : lower));
let day = clamp(get("day") || 1, 1, MAX_DAY);
let checks = safeObject(get("checks"));
let records = safeObject(get("records"));
let savedDays = safeObject(get("challenge_saved_days"));
let continuation = get("continue") === "yes";
let recordDirty = false;
let toastTimer = null;

function toast(message) {
  const node = $("toast"); node.textContent = message; node.classList.add("show");
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.classList.remove("show"), 3000);
}
function taskCount(whichDay) {
  let count = 0;
  for (let i = 0; i < 4; i++) if (checks[`${whichDay}-${i}`] === true) count++;
  return count;
}
function hasProgress(whichDay) {
  return !!savedDays[whichDay] || Array.from({ length: 4 }, (_, i) => `${whichDay}-${i}`).some(key => Object.hasOwn(checks, key));
}
function percent(whichDay) { return taskCount(whichDay) * 25; }
function dateForDay(n) {
  const dateString = get("challenge_start_date");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateString || "")) return "";
  const date = new Date(`${dateString}T12:00:00`);
  if (Number.isNaN(date.getTime())) return "";
  date.setDate(date.getDate() + n - 1);
  return `${date.getMonth() + 1}/${date.getDate()}`;
}
function renderCalendar() {
  const grid = $("calendarGrid"); grid.replaceChildren();
  for (let n = 1; n <= DAYS; n++) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `calendar-day${day === n ? " selected" : ""}`;
    button.setAttribute("aria-label", `${n}日目${dateForDay(n) ? `、${dateForDay(n)}` : ""}、達成率${percent(n)}%`);
    button.setAttribute("aria-pressed", String(day === n));
    const num = document.createElement("span"); num.className = "day-num"; num.textContent = `${n}日目`;
    const date = document.createElement("span"); date.className = "day-date"; date.textContent = dateForDay(n);
    const bar = document.createElement("span"); bar.className = "day-bar";
    const fill = document.createElement("i"); fill.style.width = `${percent(n)}%`; bar.append(fill);
    const pct = document.createElement("span"); pct.className = "day-pct"; pct.textContent = hasProgress(n) ? `${percent(n)}%` : "未記録";
    button.append(num, date, bar, pct);
    button.addEventListener("click", () => selectDay(n));
    grid.appendChild(button);
  }
}
function renderTasks() {
  const box = $("tasks"); box.replaceChildren();
  const currentPlan = plans[(day - 1) % plans.length];
  for (let i = 0; i < currentPlan.length; i++) {
    const label = document.createElement("label"); label.className = "task";
    const input = document.createElement("input"); input.type = "checkbox";
    input.checked = checks[`${day}-${i}`] === true;
    input.setAttribute("aria-label", currentPlan[i]);
    input.addEventListener("change", () => {
      checks[`${day}-${i}`] = input.checked;
      set("checks", JSON.stringify(checks));
      savedDays[day] = true;
      set("challenge_saved_days", JSON.stringify(savedDays));
      render();
    });
    const text = document.createElement("span"); text.textContent = currentPlan[i];
    label.append(input, text); box.appendChild(label);
  }
}
function render() {
  const count = taskCount(day);
  $("day").textContent = `${day}日目`;
  $("pct").textContent = `${percent(day)}%`;
  $("fill").style.width = `${percent(day)}%`;
  $("count").textContent = `${count} / 4 完了`;
  $("selectedDate").textContent = `${dateForDay(day) ? `開始日から数えて ${dateForDay(day)} ｜ ` : ""}${day > 30 ? "継続モード" : "30日チャレンジ"}`;
  $("planLabel").textContent = `${day}日目のメニュー${day > 30 ? "（継続）" : ""}`;
  $("healthDay").textContent = `${day}日目の記録を確認・編集`;
  const sum = Array.from({ length: DAYS }, (_, i) => taskCount(i + 1)).reduce((a, b) => a + b, 0);
  const total = Math.round(sum / (DAYS * 4) * 100);
  $("total").textContent = `${total}%`;
  $("totalfill").style.width = `${total}%`;
  $("totalCount").textContent = `${sum} / 120 項目を完了`;
  $("modeStatus").textContent = continuation ? `継続モード有効（現在${day}日目）` : "現在は30日モード";
  $("continueButton").textContent = continuation ? "継続モードは有効です" : "継続モードを有効にする";
  $("continueButton").disabled = continuation;
  renderTasks(); renderCalendar(); drawChart();
}
function saveDay() {
  set("checks", JSON.stringify(checks));
  savedDays[day] = true; set("challenge_saved_days", JSON.stringify(savedDays));
  render(); toast(`${day}日目の進捗を保存しました`);
}
function validRange(id, min, max) {
  const raw = $(id).value.trim();
  if (raw === "") return true;
  const value = Number(raw);
  return Number.isFinite(value) && value >= min && value <= max;
}
function saveRecord(silent = false) {
  if (!validRange("condition", 1, 5) || !validRange("mood", 1, 5) || !validRange("sleep", 0, 24)) {
    toast("体調・気分は1〜5、睡眠時間は0〜24で入力してください");
    return false;
  }
  records[day] = {
    condition: $("condition").value.trim(),
    mood: $("mood").value.trim(),
    sleep: $("sleep").value.trim(),
    memo: $("memo").value
  };
  set("records", JSON.stringify(records));
  recordDirty = false;
  drawChart();
  if (!silent) toast(`${day}日目の体調記録を保存しました`);
  return true;
}
function loadRecord() {
  const record = records[day] && typeof records[day] === "object" ? records[day] : {};
  for (const key of ["condition", "mood", "sleep", "memo"]) $(key).value = record[key] ?? "";
  recordDirty = false;
}
function selectDay(next) {
  next = clamp(next, 1, MAX_DAY);
  if (next > DAYS && !continuation) {
    toast("31日目以降は継続モードを有効にしてください"); return;
  }
  if (recordDirty && !saveRecord(true)) return;
  day = next;
  set("day", String(day));
  render(); loadRecord();
  if (day > 30) $("training").scrollIntoView({ behavior: "smooth", block: "start" });
}
function nextDay() {
  if (day >= DAYS && !continuation) { toast("続ける場合は継続モードを有効にしてください"); return; }
  selectDay(day + 1);
}
function prevDay() { selectDay(day - 1); }
function enableContinue() {
  continuation = true;
  set("continue", "yes"); // legacy key
  render(); toast("継続モードを有効にしました");
}
function jumpToContinue() {
  if (!continuation) { toast("先に継続モードを有効にしてください"); return; }
  selectDay(31);
}

// Accessible SVG charts; all SVG values are generated from validated numeric input.
const svgNS = "http://www.w3.org/2000/svg";
function svgEl(type, attributes, text) {
  const node = document.createElementNS(svgNS, type);
  for (const [key, value] of Object.entries(attributes || {})) node.setAttribute(key, String(value));
  if (text !== undefined) node.textContent = text;
  return node;
}
function drawChart() {
  const type = $("chartType").value;
  const recent = $("chartRange").value === "recent";
  const end = recent ? Math.max(DAYS, day) : DAYS;
  const start = end - DAYS + 1;
  const svg = $("chart"); svg.replaceChildren();
  const max = type === "progress" ? 100 : type === "sleep" ? 24 : 5;
  const top = 24, bottom = 212, left = 49, right = 718;
  const x = d => left + (d - start + 0.5) / DAYS * (right - left);
  const y = value => bottom - value / max * (bottom - top);
  for (let n = 0; n <= 4; n++) {
    const v = max * n / 4;
    const yy = y(v);
    svg.append(svgEl("line", {x1:left,y1:yy,x2:right,y2:yy,stroke:"#41403b","stroke-width":1}));
    svg.append(svgEl("text",{x:left-9,y:yy+4,"text-anchor":"end",fill:"#bcb8aa","font-size":12},Number.isInteger(v)?String(v):v.toFixed(1)));
  }
  const values = [];
  for (let d = start; d <= end; d++) {
    let v = null;
    if (type === "progress") { if (hasProgress(d)) v = percent(d); }
    else {
      const r = records[d];
      if (r && r[type] !== undefined && r[type] !== "" && r[type] !== null) {
        const numeric = Number(r[type]);
        if (Number.isFinite(numeric) && numeric >= 0 && numeric <= max) v = numeric;
      }
    }
    values.push({d, v});
    if ((d-start)%5 === 0 || d === end) svg.append(svgEl("text",{x:x(d),y:237,"text-anchor":"middle",fill:"#bcb8aa","font-size":11},String(d)));
  }
  svg.append(svgEl("text",{x:380,y:258,"text-anchor":"middle",fill:"#bcb8aa","font-size":12},"チャレンジ日数"));
  if (type === "progress") {
    for (const {d,v} of values) if (v !== null) {
      const rect = svgEl("rect",{x:x(d)-7,y:y(v),width:14,height:bottom-y(v),rx:3,fill:"#d2ae52"});
      rect.append(svgEl("title",{},`${d}日目：${v}%`)); svg.append(rect);
      if (v === 0) svg.append(svgEl("circle",{cx:x(d),cy:bottom,r:3,fill:"#d2ae52"}));
    }
  } else {
    let run = [];
    const addLine = () => {
      if (run.length >= 2) svg.append(svgEl("polyline",{points:run.map(v=>`${x(v.d)},${y(v.v)}`).join(" "),fill:"none",stroke:"#d2ae52","stroke-width":2.5,"stroke-linecap":"round","stroke-linejoin":"round"}));
      run = [];
    };
    for (const entry of values) {
      if (entry.v === null) addLine(); else run.push(entry);
    }
    addLine();
    for (const {d,v} of values) if (v !== null) {
      const circle = svgEl("circle",{cx:x(d),cy:y(v),r:4,fill:"#e2c56b"});
      circle.append(svgEl("title",{},`${d}日目：${v}`)); svg.append(circle);
    }
  }
  const recorded = values.filter(item => item.v !== null).length;
  $("chartHint").textContent = recorded ? `${start}〜${end}日目のうち、${recorded}日分のデータを表示しています。` : "この期間にはまだ記録がありません。";
  svg.setAttribute("aria-label", `${$("chartType").selectedOptions[0].textContent}、${start}日目から${end}日目、記録${recorded}日分`);
}

// Reminders are scheduled by Android's AlarmManager, not by JavaScript timers.
function nativeAvailable() { return typeof window.AndroidBridge !== "undefined"; }
function displayReminderState() {
  let nativeTime = "";
  if (nativeAvailable()) {
    try { nativeTime = window.AndroidBridge.getReminderTime() || ""; } catch (_) { /* no native bridge */ }
  }
  const previouslyEntered = get("reminder") || "";
  if (nativeTime) $("reminder").value = nativeTime;
  else if (previouslyEntered) $("reminder").value = previouslyEntered;
  $("reminderStatus").textContent = nativeTime ? `通知ON：毎日 ${nativeTime} 頃（端末の設定により遅れることがあります）` : previouslyEntered ? `以前の設定時刻：${previouslyEntered}。通知を利用するには「通知をON」を押してください。` : "通知は設定されていません。";
}
function enableReminder() {
  const time = $("reminder").value;
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) { toast("通知時刻を選択してください"); return; }
  set("reminder", time); // retain legacy UI preference
  if (!nativeAvailable()) { toast("Androidアプリ上で通知を設定してください"); return; }
  try { window.AndroidBridge.setReminder(time); displayReminderState(); toast("通知時刻を設定しました。必要なら通知を許可してください"); }
  catch (_) { toast("通知設定を保存できませんでした"); }
}
function disableReminder() {
  if (nativeAvailable()) { try { window.AndroidBridge.clearReminder(); } catch (_) { toast("通知を解除できませんでした"); return; } }
  set("reminder", "");
  displayReminderState(); toast("毎日の通知をOFFにしました");
}
window.onNotificationPermissionChanged = function(allowed) {
  displayReminderState();
  if (!allowed) { $("reminderStatus").textContent += "（通知が許可されていません。端末の設定を確認してください）"; toast("通知が許可されていません"); }
};

function exportBackup() {
  if (recordDirty && !saveRecord(true)) return;
  const data = {
    challengeBackupVersion:2, exportedAt:new Date().toISOString(),
    day, checks, records, savedDays, continuation,
    startDate:get("challenge_start_date") || "", reminder:get("reminder") || ""
  };
  const json = JSON.stringify(data, null, 2);
  if (nativeAvailable()) {
    try { window.AndroidBridge.exportBackup(json); return; } catch (_) { /* fallback below */ }
  }
  const blob = new Blob([json], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = "challenge-backup.json"; a.click();
  setTimeout(()=>URL.revokeObjectURL(url),3000);
}
function importBackup() {
  if (nativeAvailable()) { try { window.AndroidBridge.importBackup(); return; } catch (_) { /* fallback */ } }
  const raw = window.prompt("バックアップJSONのテキストを貼り付けてください");
  if (raw) window.receiveNativeBackup(raw);
}
window.receiveNativeBackup = function(json) {
  let input;
  try { input = JSON.parse(json); } catch (_) { toast("JSONファイルを読み込めませんでした"); return; }
  if (!input || input.challengeBackupVersion !== 2 || typeof input.checks !== "object" || typeof input.records !== "object" || !input.checks || !input.records || Array.isArray(input.records)) {
    toast("このアプリのバックアップファイルではありません"); return;
  }
  if (!window.confirm("バックアップを読み込みますか？同じ日の記録はバックアップの内容に更新されます。")) return;
  const incomingChecks = {};
  for (const [key,value] of Object.entries(input.checks)) {
    if (/^\d{1,4}-[0-3]$/.test(key) && Number(key.split("-")[0]) <= MAX_DAY && typeof value === "boolean") incomingChecks[key] = value;
  }
  const incomingRecords = {};
  for (const [key,value] of Object.entries(input.records)) {
    if (!/^\d{1,4}$/.test(key) || +key < 1 || +key > MAX_DAY || !value || typeof value !== "object" || Array.isArray(value)) continue;
    const safe = {};
    for (const field of ["condition","mood","sleep","memo"]) safe[field] = String(value[field] ?? "").slice(0,field==="memo"?3000:12);
    incomingRecords[key] = safe;
  }
  checks = {...checks, ...incomingChecks}; records = {...records,...incomingRecords};
  savedDays = {...savedDays, ...((input.savedDays && typeof input.savedDays === "object") ? Object.fromEntries(Object.entries(input.savedDays).filter(([k])=>/^\d{1,4}$/.test(k) && +k<=MAX_DAY)) : {})};
  continuation = continuation || input.continuation === true;
  day = clamp(input.day || day, 1, continuation ? MAX_DAY : DAYS);
  set("checks",JSON.stringify(checks));set("records",JSON.stringify(records));set("challenge_saved_days",JSON.stringify(savedDays));
  set("day",String(day)); if(continuation) set("continue","yes");
  if (/^\d{4}-\d{2}-\d{2}$/.test(input.startDate || "")) {set("challenge_start_date",input.startDate);$("startDate").value=input.startDate;}
  render();loadRecord();toast("バックアップを読み込みました。記録を確認してください");
};
window.onBackupExported = function(ok) { toast(ok ? "バックアップを保存しました" : "バックアップの保存が取り消されました"); };

// Keep legacy values untouched until the user changes them.
$("startDate").value = get("challenge_start_date") || "";
$("startDate").addEventListener("change", () => {set("challenge_start_date",$("startDate").value);renderCalendar();render();});
for (const id of ["condition","mood","sleep","memo"]) $(id).addEventListener("input",()=>{recordDirty = true;});
render();loadRecord();displayReminderState();
