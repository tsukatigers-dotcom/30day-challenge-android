plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "jp.example.challenge"
    compileSdk = 35

    defaultConfig {
        applicationId = "jp.example.challenge"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "2.0"
    }

    // Two variants: original package for eligible in-place updates, and a safe
    // side-by-side install that leaves the existing app and its data untouched.
    flavorDimensions += "installation"
    productFlavors {
        create("original") {
            dimension = "installation"
            resValue("string", "app_name", "絶倫体質30日間チャレンジ")
        }
        create("safe") {
            dimension = "installation"
            applicationIdSuffix = ".plus"
            resValue("string", "app_name", "絶倫体質30日間チャレンジ＋")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
